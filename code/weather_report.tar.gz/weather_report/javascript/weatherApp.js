angular.module('weatherApp',['ui.router','chart.js'])

//config start
.config(function($stateProvider,$urlRouterProvider){

	$stateProvider
		.state('cities',{
			url: '/cities',
			templateUrl: 'templates/cities.html',
			controller: 'citiesController'
		})
		.state('cityReport',{
			url:'/cityReport',
			params: {'name': null},
			templateUrl: 'templates/cityReport.html',
			controller: 'cityReportController',
			
		});

	$urlRouterProvider.otherwise('/cities');
})

//controller start

.controller('citiesController',function($scope,$state,$http){

	$scope.labels=[];
	$scope.data=[];
	/*http request to get weather report of bangalore,chennai,hyderabad,mumbai,delhi. Change the id in the url parameters 
	from city.list.json file*/

	$http.get("http://api.openweathermap.org/data/2.5/group?id=1269843,1273294,1277333,1264527,1275339&units=metric&appid=c5c0b9c84b1d553a8be59d1a41bf3dad")
  	.then(function(response){ 
  		
  		$scope.details = JSON.parse(JSON.stringify(response.data)).list;
  		console.log("Response result:",$scope.details);
  		$scope.plotChart(); 
  	});

  	$scope.plotChart=function(){
  		if(typeof($scope.details) !== undefined){
  			for(var i in $scope.details){
  				$scope.labels[i]=$scope.details[i].name;
  				$scope.data[i]=$scope.details[i].main.temp;
  			}	
  		}
  		
  		$scope.data.sort();
		$scope.series = ['Temp °C'];
  	};

  	$scope.stateTransition=function(points,evt){
  		if(points.length > 0 && (points[0]._model.label === $scope.labels[points[0]._index])) {
  				$state.go('cityReport',{ 'name' : points[0]._model.label });
		 		console.log("the point is",points[0]._model.label);	
		}
		else{
			console.log("You haven't clicked inside the graph");
		}
  	};
})
.controller('cityReportController',function($scope,$state,$http,$stateParams){

	$scope.cityName=$stateParams.name;
	$scope.data=[[],[]];
	$scope.labels=[];
	$http.get("http://api.openweathermap.org/data/2.5/forecast/daily?q="+$stateParams.name+"&cnt=7&units=metric&appId=d34106d5b35b36bff4970a37bc2507dc")
  	.then(function(response){ 
  		$scope.forecast = JSON.parse(JSON.stringify(response.data)).list;
  		console.log("specific city forecast for 7 days",$scope.forecast);
  		$scope.plotChart(); 
  	});
  	var today=(new Date()).getDay();
  	var dayOfWeek=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  	$scope.plotChart=function(){
  		if(typeof($scope.forecast) !== undefined){
  			for(var i in $scope.forecast){
  				$scope.data[0].push($scope.forecast[i].temp.max);
  				$scope.labels[i]=dayOfWeek[(today+parseInt(i))%7];
  				$scope.data[1].push($scope.forecast[i].temp.min);
			}
  		}
  		
  		$scope.series = ['max °C','min °C'];
	};
});